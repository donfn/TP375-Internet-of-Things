
#define INTERRUPT_PIN 33 // Pin connected to the OUT of the sensor

unsigned long lastTime = 0;
int tick = 0 ;

void setup() {
  Serial.begin(115200); // Initialize Serial communication
  pinMode(INTERRUPT_PIN, INPUT); // Set the interrupt pin as input
  attachInterrupt(digitalPinToInterrupt(INTERRUPT_PIN), speedInterrupt, FALLING); // Attach the interrupt
}

void loop() {
  // Display the speed on the Serial Monitor every second
  if (millis() - lastTime >= 1000) {
    Serial.print("Ticks per second: ");
    Serial.println(tick);
    lastTime = millis();
    
    tick = 0 ;
    
  }
}

void speedInterrupt() {
  tick++;
}

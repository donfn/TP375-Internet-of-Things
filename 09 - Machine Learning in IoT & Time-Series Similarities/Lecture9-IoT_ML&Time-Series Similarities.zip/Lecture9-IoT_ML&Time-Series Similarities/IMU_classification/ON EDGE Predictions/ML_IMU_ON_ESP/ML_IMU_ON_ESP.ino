//Libraries Definition 
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>
#include "mymodel.h"


//Constants Definition
#define NUM_SAMPLES 30
#define NUM_AXES 3
#define TRUNCATE 20
#define ACCEL_THRESHOLD 20
#define INTERVAL 30

//variables definition
float baseline[NUM_AXES];
float features[NUM_SAMPLES * NUM_AXES];
    int flag=0;
Adafruit_MPU6050 imu;

void imu_setup(){
  Wire.begin();
  Serial.println("Adafruit MPU6050 test!");
  // Try to initialize!
  if (!imu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) {
      delay(10);
    }
  }
  Serial.println("MPU6050 Found!");
  imu.setAccelerometerRange(MPU6050_RANGE_8_G);
  Serial.print("Accelerometer range set to: ");
  switch (imu.getAccelerometerRange()) {
  case MPU6050_RANGE_2_G:
    Serial.println("+-2G");
    break;
  case MPU6050_RANGE_4_G:
    Serial.println("+-4G");
    break;
  case MPU6050_RANGE_8_G:
    Serial.println("+-8G");
    break;
  case MPU6050_RANGE_16_G:
    Serial.println("+-16G");
    break;
  }
  imu.setGyroRange(MPU6050_RANGE_500_DEG);
  Serial.print("Gyro range set to: ");
  switch (imu.getGyroRange()) {
  case MPU6050_RANGE_250_DEG:
    Serial.println("+- 250 deg/s");
    break;
  case MPU6050_RANGE_500_DEG:
    Serial.println("+- 500 deg/s");
    break;
  case MPU6050_RANGE_1000_DEG:
    Serial.println("+- 1000 deg/s");
    break;
  case MPU6050_RANGE_2000_DEG:
    Serial.println("+- 2000 deg/s");
    break;
  }
  imu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  Serial.print("Filter bandwidth set to: ");
  switch (imu.getFilterBandwidth()) {
  case MPU6050_BAND_260_HZ:
    Serial.println("260 Hz");
    break;
  case MPU6050_BAND_184_HZ:
    Serial.println("184 Hz");
    break;
  case MPU6050_BAND_94_HZ:
    Serial.println("94 Hz");
    break;
  case MPU6050_BAND_44_HZ:
    Serial.println("44 Hz");
    break;
  case MPU6050_BAND_21_HZ:
    Serial.println("21 Hz");
    break;
  case MPU6050_BAND_10_HZ:
    Serial.println("10 Hz");
    break;
  case MPU6050_BAND_5_HZ:
    Serial.println("5 Hz");
    break;
  }
  }

// function to read data from imu
void imu_read(float *ax, float *ay, float *az) {
    int16_t _ax, _ay, _az, _gx, _gy, _gz;
    sensors_event_t a, g, temp;
    imu.getEvent(&a, &g, &temp);
    *ax = a.acceleration.x;
    *ay = a.acceleration.y;
    *az = a.acceleration.z;
 }

//basic setup function
void setup() {
  Serial.begin(115200);
  delay(20);
  imu_setup(); //setup basic parameters of imu and detect chip specs
  calibrate(); //gettin initial positions info
 
}

void loop() {
 
    float ax, ay, az;

    if (flag==0){
        Serial.println("Ready, waitting for move");    
        }
    imu_read(&ax, &ay, &az);
    ax = constrain(ax - baseline[0], -TRUNCATE, TRUNCATE);
    ay = constrain(ay - baseline[1], -TRUNCATE, TRUNCATE);
    az = constrain(az - baseline[2], -TRUNCATE, TRUNCATE);

    if (!motionDetected(ax, ay, az)) {
        flag=1;
        delay(10);
        return;
        }
       flag=0;
    recordIMU();//record num_sumples data points vector according to initial settings 
    //if in dataset creation mode thne you should uncomment the printFeatures() command and comment classify() command
   // printFeatures();
    //if in prediction mode then you should comment the printFeatures() command and uncomment classify() command below
    classify();
    delay(2000); //otan grafeis tis kiniseis na perimeneis 2 sec prin apo kathe kinisi....
}

void calibrate() {
    Serial.println("Callibrating.....miso....");
    float ax, ay, az;
    for (int i = 0; i < 10; i++) {
        imu_read(&ax, &ay, &az);
        delay(100);
    }
    baseline[0] = ax;
    baseline[1] = ay;
    baseline[2] = az;
    Serial.println("ok....ksekina");
}


/**
 * Detect if motion is happening
 * @return
 */
bool motionDetected(float ax, float ay, float az) {
    return (abs(ax) + abs(ay) + abs(az)) > ACCEL_THRESHOLD;
}

/**
 * Fill the feature vector
 */
void recordIMU() {
    float ax, ay, az;

    for (int i = 0; i < NUM_SAMPLES; i++) {
        imu_read(&ax, &ay, &az);

        ax = constrain(ax - baseline[0], -TRUNCATE, TRUNCATE);
        ay = constrain(ay - baseline[1], -TRUNCATE, TRUNCATE);
        az = constrain(az - baseline[2], -TRUNCATE, TRUNCATE);

        features[i * NUM_AXES + 0] = ax;
        features[i * NUM_AXES + 1] = ay;
        features[i * NUM_AXES + 2] = az;

        delay(INTERVAL);
    }
}

/**
 * Dump the feature vector to Serial monitor
 */
void printFeatures() {
    const uint16_t numFeatures = sizeof(features) / sizeof(float);

    for (int i = 0; i < numFeatures; i++) {
        Serial.print(features[i]);
        Serial.print(i == numFeatures - 1 ? '\n' : ',');
    }
}


 

void classify() {
    Serial.print("Detected gesture: ");
    Serial.println(predictLabel(features));
}

#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include "mpu6050_svm_model.h"  

#define START_BUTTON_PIN 12
#define STOP_BUTTON_PIN  19

Eloquent::ML::Port::MPU6050SVM svm;

Adafruit_MPU6050 mpu;

const int WINDOW_SIZE = 30; 
bool predicting = false;
int sampleIndex = 0;

float ax_window[WINDOW_SIZE];
float ay_window[WINDOW_SIZE];
float az_window[WINDOW_SIZE];
float gx_window[WINDOW_SIZE];
float gy_window[WINDOW_SIZE];
float gz_window[WINDOW_SIZE];

// Offsets for calibration
float ax_offset = 0, ay_offset = 0, az_offset = 0;
float gx_offset = 0, gy_offset = 0, gz_offset = 0;

void calibrateSensor() {
  Serial.println("Calibrating... Keep MPU still.");
  const int CALIB_SAMPLES = 100;
  float ax_sum=0, ay_sum=0, az_sum=0, gx_sum=0, gy_sum=0, gz_sum=0;

  for (int i=0; i<CALIB_SAMPLES; i++) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    ax_sum += a.acceleration.x;
    ay_sum += a.acceleration.y;
    az_sum += a.acceleration.z;
    gx_sum += g.gyro.x;
    gy_sum += g.gyro.y;
    gz_sum += g.gyro.z;
    delay(10);
  }

  ax_offset = ax_sum / CALIB_SAMPLES;
  ay_offset = ay_sum / CALIB_SAMPLES;
  az_offset = az_sum / CALIB_SAMPLES - 9.80665;

  gx_offset = gx_sum / CALIB_SAMPLES;
  gy_offset = gy_sum / CALIB_SAMPLES;
  gz_offset = gz_sum / CALIB_SAMPLES;

  Serial.println("Calibration done.");
}

float meanFilter(float newVal, float *window, int size) {
  static float sum = 0;
  static int count = 0;
  static int index = 0;

  sum -= window[index];
  window[index] = newVal;
  sum += newVal;

  index = (index + 1) % size;
  count = min(count + 1, size);

  return sum / count;
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(START_BUTTON_PIN, INPUT_PULLUP);
  pinMode(STOP_BUTTON_PIN, INPUT_PULLUP);

  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) { delay(10); }
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  calibrateSensor();

  Serial.println("Press START to begin prediction.");
}

void loop() {
  bool startPressed = digitalRead(START_BUTTON_PIN) == LOW;
  bool stopPressed  = digitalRead(STOP_BUTTON_PIN) == LOW;

  if (startPressed && !predicting) {
    predicting = true;
    sampleIndex = 0;
    Serial.println("Prediction started.");
    delay(500);
  }

  if (stopPressed && predicting) {
    predicting = false;
    Serial.println("Prediction stopped.");
    sampleIndex = 0;
    delay(500);
  }

  if (predicting) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    float ax = a.acceleration.x - ax_offset;
    float ay = a.acceleration.y - ay_offset;
    float az = a.acceleration.z - az_offset;

    float gx = g.gyro.x - gx_offset;
    float gy = g.gyro.y - gy_offset;
    float gz = g.gyro.z - gz_offset;

    static float axFilt[WINDOW_SIZE] = {0};
    static float ayFilt[WINDOW_SIZE] = {0};
    static float azFilt[WINDOW_SIZE] = {0};
    static float gxFilt[WINDOW_SIZE] = {0};
    static float gyFilt[WINDOW_SIZE] = {0};
    static float gzFilt[WINDOW_SIZE] = {0};

    float ax_m = meanFilter(ax, axFilt, WINDOW_SIZE);
    float ay_m = meanFilter(ay, ayFilt, WINDOW_SIZE);
    float az_m = meanFilter(az, azFilt, WINDOW_SIZE);
    float gx_m = meanFilter(gx, gxFilt, WINDOW_SIZE);
    float gy_m = meanFilter(gy, gyFilt, WINDOW_SIZE);
    float gz_m = meanFilter(gz, gzFilt, WINDOW_SIZE);

    ax_window[sampleIndex] = ax_m;
    ay_window[sampleIndex] = ay_m;
    az_window[sampleIndex] = az_m;
    gx_window[sampleIndex] = gx_m;
    gy_window[sampleIndex] = gy_m;
    gz_window[sampleIndex] = gz_m;

    sampleIndex++;

    if (sampleIndex >= WINDOW_SIZE) {
      sampleIndex = 0;
      runPrediction();
    }
  }

  delay(50); 
}

void runPrediction() {
  float inputFeatures[WINDOW_SIZE * 6];
  int idx = 0;
  for (int i = 0; i < WINDOW_SIZE; i++) {
    inputFeatures[idx++] = ax_window[i];
    inputFeatures[idx++] = ay_window[i];
    inputFeatures[idx++] = az_window[i];
    inputFeatures[idx++] = gx_window[i];
    inputFeatures[idx++] = gy_window[i];
    inputFeatures[idx++] = gz_window[i];
  }

int predicted = svm.predict(inputFeatures);
  const char* labels[] = {"A", "M", "O"};  

  Serial.print("Prediction: ");
  Serial.println(labels[predicted]);
}

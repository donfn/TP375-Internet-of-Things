#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

#define START_BUTTON_PIN 12
#define STOP_BUTTON_PIN  19

Adafruit_MPU6050 mpu;

const int WINDOW_SIZE = 30; 

float ax_window[WINDOW_SIZE];
float ay_window[WINDOW_SIZE];
float az_window[WINDOW_SIZE];
float gx_window[WINDOW_SIZE];
float gy_window[WINDOW_SIZE];
float gz_window[WINDOW_SIZE];

int sampleIndex = 0;
bool recording = false;

char label = 'M'; 

float ax_offset = 0, ay_offset = 0, az_offset = 0;
float gx_offset = 0, gy_offset = 0, gz_offset = 0;

void calibrateSensor() {
  Serial.println("Calibrating... Keep MPU still.");
  const int CALIB_SAMPLES = 100;
  float ax_sum=0, ay_sum=0, az_sum=0, gx_sum=0, gy_sum=0, gz_sum=0;

  for (int i=0; i<CALIB_SAMPLES; i++) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);
    ax_sum += a.acceleration.x;
    ay_sum += a.acceleration.y;
    az_sum += a.acceleration.z;
    gx_sum += g.gyro.x;
    gy_sum += g.gyro.y;
    gz_sum += g.gyro.z;
    delay(10);
  }
  ax_offset = ax_sum / CALIB_SAMPLES;
  ay_offset = ay_sum / CALIB_SAMPLES;
  az_offset = az_sum / CALIB_SAMPLES - 9.80665; // gravity offset

  gx_offset = gx_sum / CALIB_SAMPLES;
  gy_offset = gy_sum / CALIB_SAMPLES;
  gz_offset = gz_sum / CALIB_SAMPLES;

  Serial.println("Calibration done.");
  Serial.print("Offsets: ");
  Serial.print(ax_offset,4); Serial.print(", ");
  Serial.print(ay_offset,4); Serial.print(", ");
  Serial.print(az_offset,4); Serial.print(", ");
  Serial.print(gx_offset,4); Serial.print(", ");
  Serial.print(gy_offset,4); Serial.print(", ");
  Serial.println(gz_offset,4);
}

float meanFilter(float newVal, float *window, int size) {
  static float sum = 0;
  static int count = 0;
  static int index = 0;

  sum -= window[index];
  window[index] = newVal;
  sum += newVal;

  index = (index + 1) % size;
  count = min(count + 1, size);

  return sum / count;
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(START_BUTTON_PIN, INPUT_PULLUP);
  pinMode(STOP_BUTTON_PIN, INPUT_PULLUP);

  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) { delay(10); }
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  calibrateSensor();

  Serial.println("Set label (M/O/A) via Serial Monitor and press Enter.");
  Serial.println("Press START button to begin recording.");
}

void loop() {
  // Read serial label input if available
  if (Serial.available() > 0) {
    char c = Serial.read();
    if (c == 'M' || c == 'O' || c == 'A') {
      label = c;
      Serial.print("Label set to: ");
      Serial.println(label);
    }
  }

  bool startPressed = digitalRead(START_BUTTON_PIN) == LOW;
  bool stopPressed = digitalRead(STOP_BUTTON_PIN) == LOW;

  if (startPressed && !recording) {
    recording = true;
    sampleIndex = 0;
    Serial.println("Recording started.");
    delay(500); // debounce
  }

  if (stopPressed && recording) {
    recording = false;
    Serial.println("Recording stopped.");
    printGestureData();
    sampleIndex = 0;
    delay(500); // debounce
  }

  if (recording) {
    sensors_event_t a, g, temp;
    mpu.getEvent(&a, &g, &temp);

    float ax = a.acceleration.x - ax_offset;
    float ay = a.acceleration.y - ay_offset;
    float az = a.acceleration.z - az_offset;

    float gx = g.gyro.x - gx_offset;
    float gy = g.gyro.y - gy_offset;
    float gz = g.gyro.z - gz_offset;

    static float axFilt[WINDOW_SIZE] = {0};
    static float ayFilt[WINDOW_SIZE] = {0};
    static float azFilt[WINDOW_SIZE] = {0};
    static float gxFilt[WINDOW_SIZE] = {0};
    static float gyFilt[WINDOW_SIZE] = {0};
    static float gzFilt[WINDOW_SIZE] = {0};

    float ax_m = meanFilter(ax, axFilt, WINDOW_SIZE);
    float ay_m = meanFilter(ay, ayFilt, WINDOW_SIZE);
    float az_m = meanFilter(az, azFilt, WINDOW_SIZE);
    float gx_m = meanFilter(gx, gxFilt, WINDOW_SIZE);
    float gy_m = meanFilter(gy, gyFilt, WINDOW_SIZE);
    float gz_m = meanFilter(gz, gzFilt, WINDOW_SIZE);

    ax_window[sampleIndex] = ax_m;
    ay_window[sampleIndex] = ay_m;
    az_window[sampleIndex] = az_m;
    gx_window[sampleIndex] = gx_m;
    gy_window[sampleIndex] = gy_m;
    gz_window[sampleIndex] = gz_m;

    sampleIndex++;

    if (sampleIndex >= WINDOW_SIZE) {
      recording = false;
      Serial.println("Recording stopped (window full).");
      printGestureData();
      sampleIndex = 0;
      delay(500);
    }
  }

  delay(50);
}

void printGestureData() {
  Serial.print(label);

  for (int i=0; i<sampleIndex; i++) {
    Serial.print(",");
    Serial.print(ax_window[i], 2); Serial.print(",");
    Serial.print(ay_window[i], 2); Serial.print(",");
    Serial.print(az_window[i], 2); Serial.print(",");
    Serial.print(gx_window[i], 2); Serial.print(",");
    Serial.print(gy_window[i], 2); Serial.print(",");
    Serial.print(gz_window[i], 2);
  }
  Serial.println();
}

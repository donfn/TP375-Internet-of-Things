float numA;
float numB;
char  oper;

void setup()
{
  Serial.begin(9600);
}

void loop()
{
  Serial.print("Enter the first number: ");
  while(!Serial.available());
  numA = Serial.parseFloat();
  Serial.print(String(numA));
  Serial.print(" \r\n");
  
  Serial.print("Enter the operand (+, -, *, /): ");
  while(!Serial.available());
  oper = Serial.read();
  Serial.print(String(oper));
  Serial.print(" \r\n");
  
  Serial.print("Enter the second number: ");
  while(!Serial.available());
  numB = Serial.parseFloat();
  Serial.print(String(numB));
  Serial.print(" \r\n");

  switch(oper)
  {
    case '+':
      Serial.println(numA + numB);
      break;
    case '-':
      Serial.println(numA - numB);
      break;
    case '*':
      Serial.println(numA * numB);
      break;
    case '/':
      Serial.println(numA / numB);
      break;
    default:
      Serial.println("Invalid data.");
  }
}

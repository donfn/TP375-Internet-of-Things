#include "RunningMedian.h"

RunningMedian samples = RunningMedian(15);

long count = 0;
float numA;

void setup()
{
  Serial.begin(9600);
  Serial.print(F("Running Median Version: "));
  Serial.println(RUNNING_MEDIAN_VERSION);
}

void loop()
{
  Serial.print("Enter value: ");
  while(!Serial.available());
  numA = Serial.parseFloat();
  Serial.print(" \r\n");
  median();  
}

void median()
{
  if (count % 20 == 0) Serial.println(F("\nmsec \tAnR \tSize \tCnt \tLow \tAvg \tAvg(3) \tMed \tHigh"));
  count++;

  samples.add(numA);

  float l = samples.getLowest();
  float m = samples.getMedian();
  float a = samples.getAverage();
  float a3 = samples.getAverage(3);
  float h = samples.getHighest();
  int s = samples.getSize();
  int c = samples.getCount();

  Serial.print(millis());
  Serial.print('\t');
  Serial.print(numA);
  Serial.print('\t');
  Serial.print(s);
  Serial.print('\t');
  Serial.print(c);
  Serial.print('\t');
  Serial.print(l);
  Serial.print('\t');
  Serial.print(a, 2);
  Serial.print('\t');
  Serial.print(a3, 2);
  Serial.print('\t');
  Serial.print(m);
  Serial.print('\t');
  Serial.println(h);
  delay(100);
}

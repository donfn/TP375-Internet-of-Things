#include "RunningMedian.h"
#include <OneWire.h>
#include <DallasTemperature.h>

#define OWB 2
#define BTN 3

OneWire ONEWIRE(OWB);
DallasTemperature DS18B20(&ONEWIRE);

RunningMedian samples = RunningMedian(5);
long count = 0;
bool flag;
float temp;

void setup(void)
{
  pinMode(BTN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(3), interruptHandler, FALLING);
  Serial.begin(9600);
  while (!Serial) ;
  DS18B20.begin();
}

void loop(void)
{
  while ( flag )
  {
    DS18B20.requestTemperatures(); // Send the command to get temperatures
    temp = DS18B20.getTempCByIndex(0);
    tempmedian();
  }
}

void interruptHandler(void)
{
  flag = !flag;
}

void tempmedian()
{
  if (count % 20 == 0) Serial.println(F("\nmsec \tAnR \tSize \tCnt \tLow \tAvg \tAvg(3) \tMed \tHigh"));
  count++;

  samples.add(temp);

  float l = samples.getLowest();
  float m = samples.getMedian();
  float a = samples.getAverage();
  float a3 = samples.getAverage(3);
  float h = samples.getHighest();
  int s = samples.getSize();
  int c = samples.getCount();

  Serial.print(millis());
  Serial.print('\t');
  Serial.print(temp);
  Serial.print('\t');
  Serial.print(s);
  Serial.print('\t');
  Serial.print(c);
  Serial.print('\t');
  Serial.print(l);
  Serial.print('\t');
  Serial.print(a, 2);
  Serial.print('\t');
  Serial.print(a3, 2);
  Serial.print('\t');
  Serial.print(m);
  Serial.print('\t');
  Serial.println(h);
  delay(100);
}

#include <Wire.h>
#include "RTClib.h"

RTC_DS1307 RTC;

char weekdays[][12] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

void setup(void)
{
  Serial.begin(9600);
  while (!Serial)   ;

  while (!RTC.begin())
  {
    Serial.println("Error.");
  }

  if (!RTC.isrunning())
  {
    RTC.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }
}

void loop(void)
{
    DateTime now = RTC.now();
    
    Serial.print(now.year(), DEC);
    Serial.print('/');
    
    Serial.print(now.month(), DEC);
    Serial.print('/');
    
    Serial.print(now.day(), DEC);
    Serial.print(" (");
    Serial.print(weekdays[now.dayOfTheWeek()]);
    Serial.print(") ");
    
    Serial.print(now.hour(), DEC);
    Serial.print(':');
    Serial.print(now.minute(), DEC);
    Serial.print(':');
    Serial.print(now.second(), DEC);
    Serial.print("\r\n");
        
    delay(5000);
}

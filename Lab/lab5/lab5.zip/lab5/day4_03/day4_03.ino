#include "Adafruit_VL53L0X.h"

Adafruit_VL53L0X L0X = Adafruit_VL53L0X();

int buzzer = 13;

void setup(void)
{
  pinMode(buzzer, OUTPUT);

  Serial.begin(9600);
  while (! Serial)  ;

  if (!L0X.begin()) ;
}

void loop(void)
{
  VL53L0X_RangingMeasurementData_t measure;
  L0X.rangingTest(&measure, false); // Change to 'true' for debugging info.

  Serial.print("Distance in (mm): ");

  if (measure.RangeStatus != 4)
  {
    Serial.print(measure.RangeMilliMeter);
    Serial.print(".\r\n");

    if (measure.RangeMilliMeter < 75)
      tone(buzzer, 2000);
    else
      noTone(buzzer);
  }
  else
  {
    Serial.print("out of range.\r\n");
  }
  delay(1000);
}

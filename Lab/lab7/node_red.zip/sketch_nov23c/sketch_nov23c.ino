bool lastgreetings;
bool greetings;
int ledState = LOW;
int buttonState;
int lastButtonState = LOW;

unsigned long lastDebounceTime = 0;
unsigned long debounceDelay = 50;

void setup() {
  Serial.begin(9600);
  pinMode(A0,INPUT);        //diavazei pot
  pinMode(7,INPUT_PULLUP);  //button gia on-off toy led sto pin 12
  pinMode(8,INPUT_PULLUP);  //button gia akoystiko minima hello kai good-bye
  pinMode(11,OUTPUT);       //pwm led
  analogWrite(11,0);
  pinMode(12,OUTPUT);       //on-off led
}

void loop() {
  int strlength;
  if (Serial.available() > 0) {       //diavazoume to string apo to nodered
  String str = Serial.readString();
  strlength= str.length();
  String chkstr = (str.substring(strlength-7, strlength-3));      //diavazoume toys 7 ws 3 telefteoys xarakthres 
  if(chkstr == "LED=")                                             // an einai LED=
      {
        String strled = str.substring(strlength-3, strlength);      //diavazoume last 3 characters 000 ws 1000
        int led = strled.toInt();
        led = map(led,0,100,0,255);
        analogWrite(11, led);
      }
  if(chkstr == "BTN=")                                            //an einai BTN= tote elexoyme to led
      {
        ledState = !ledState;
        digitalWrite(12, ledState);
       }
  }     
  Serial.println(analogRead(A0));
  greetings = digitalRead(8);
  if (greetings != lastgreetings) {
    if (greetings == LOW) {
      Serial.println("hello");
    } else {
      Serial.println("bye");
    }
  }
  lastgreetings = greetings;
  delay(100);
 
  int reading = digitalRead(7);               //apo do kai kato an pati8ei to button toy led gia on off me debounce
  if (reading != lastButtonState) {
    lastDebounceTime = millis();
  }
  if ((millis() - lastDebounceTime) > debounceDelay) {
    if (reading != buttonState) {
      buttonState = reading;
      if (buttonState == HIGH) {
        ledState = !ledState;
      }
    }
  }
  digitalWrite(12, ledState);
  if (ledState == HIGH)Serial.println("led is on");         //stelnoyme to status toy led sto node red
  else if(ledState== LOW)Serial.println("led is off");
  lastButtonState = reading;
}
